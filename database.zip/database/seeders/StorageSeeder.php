<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StorageSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $typeId = DB::table('component_types')->where('name', 'storage')->value('id');
        $categoryId = DB::table('categories')->where('name', 'like', '%storage%')->value('id');

        $storages = [
            ['Samsung 970 EVO Plus 1TB', 'NVMe', 1000, 3500, 3300, 'Samsung'],
            ['Crucial P3 1TB', 'NVMe', 1000, 3500, 3000, 'Crucial'],
            ['WD SN570 500GB', 'NVMe', 500, 3500, 2300, 'Western Digital'],
            ['Seagate Barracuda 2TB', 'SATA', 2000, 210, 190, 'Seagate'],
            ['Kingston A2000 1TB', 'NVMe', 1000, 2200, 2000, 'Kingston'],
            ['Samsung 980 500GB', 'NVMe', 500, 3100, 2600, 'Samsung'],
            ['WD Blue 1TB', 'SATA', 1000, 150, 140, 'Western Digital'],
            ['Crucial MX500 1TB', 'SATA', 1000, 560, 510, 'Crucial'],
            ['Patriot P300 512GB', 'NVMe', 512, 1700, 1200, 'Patriot'],
            ['ADATA SU800 1TB', 'SATA', 1000, 560, 520, 'ADATA'],
        ];

        foreach ($storages as [$name, $type, $capacity, $read, $write, $brandName]) {
            $brandId = DB::table('brands')->where('name', 'like', "%$brandName%")->value('id') ?? 1;

            $componentId = DB::table('components')->insertGetId([
                'name' => $name,
                'component_type_id' => $typeId,
                'brand_id' => $brandId,
                'category_id' => $categoryId,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('storages')->insert([
                'component_id' => $componentId,
                'type' => $type,
                'capacity' => $capacity,
                'read_speed' => $read,
                'write_speed' => $write,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }
}
