<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RamSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $typeId = DB::table('component_types')->where('name', 'ram')->value('id');
        $categoryId = DB::table('categories')->where('name', 'like', '%ram%')->value('id');

        $rams = [
            ['Corsair Vengeance LPX 16GB', 'DDR4', 3200, 16, 1.35, 'Corsair'],
            ['G.Skill Trident Z5 32GB', 'DDR5', 6000, 32, 1.35, 'G.Skill'],
            ['Kingston Fury Beast 16GB', 'DDR4', 3200, 16, 1.35, 'Kingston'],
            ['TeamGroup Delta RGB 32GB', 'DDR5', 6400, 32, 1.4, 'TeamGroup'],
            ['Crucial Ballistix 8GB', 'DDR4', 3000, 8, 1.2, 'Crucial'],
            ['Patriot Viper 16GB', 'DDR4', 3600, 16, 1.35, 'Patriot'],
            ['ADATA XPG Lancer 32GB', 'DDR5', 6000, 32, 1.25, 'ADATA'],
            ['Corsair Dominator Platinum 32GB', 'DDR5', 6600, 32, 1.35, 'Corsair'],
            ['G.Skill Ripjaws V 16GB', 'DDR4', 3200, 16, 1.35, 'G.Skill'],
            ['Kingston Fury Renegade 32GB', 'DDR5', 6400, 32, 1.35, 'Kingston'],
        ];

        foreach ($rams as [$name, $type, $speed, $capacity, $voltage, $brandName]) {
            $brandId = DB::table('brands')->where('name', 'like', "%$brandName%")->value('id') ?? 1;

            $componentId = DB::table('components')->insertGetId([
                'name' => $name,
                'component_type_id' => $typeId,
                'brand_id' => $brandId,
                'category_id' => $categoryId,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('rams')->insert([
                'component_id' => $componentId,
                'type' => $type,
                'speed' => $speed,
                'capacity' => $capacity,
                'voltage' => $voltage,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }
}
