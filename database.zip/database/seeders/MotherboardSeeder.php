<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MotherboardSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $typeId = DB::table('component_types')->where('name', 'motherboard')->value('id');
        $categoryId = DB::table('categories')->where('name', 'like', '%motherboard%')->value('id');

        $list = [
            ['ASUS Prime B550-PLUS', 'AM4', 'B550', 'DDR4', 4, 128, 'ATX', true, true, true, 'ASUS'],
            ['MSI MPG B550 Gaming Edge', 'AM4', 'B550', 'DDR4', 4, 128, 'ATX', true, true, true, 'MSI'],
            ['Gigabyte B550M DS3H', 'AM4', 'B550', 'DDR4', 2, 64, 'Micro-ATX', false, false, true, 'Gigabyte'],
            ['ASRock B550 Pro4', 'AM4', 'B550', 'DDR4', 4, 128, 'ATX', false, false, true, 'ASRock'],
            ['ASUS TUF Gaming Z690-PLUS', 'LGA1700', 'Z690', 'DDR5', 4, 128, 'ATX', true, true, true, 'ASUS'],
            ['MSI Z690-A PRO', 'LGA1700', 'Z690', 'DDR5', 4, 128, 'ATX', true, true, true, 'MSI'],
            ['Gigabyte Z690 UD', 'LGA1700', 'Z690', 'DDR4', 4, 128, 'ATX', false, false, true, 'Gigabyte'],
            ['ASRock Z690 Steel Legend', 'LGA1700', 'Z690', 'DDR5', 4, 128, 'ATX', true, true, true, 'ASRock'],
            ['MSI B650M Mortar', 'AM5', 'B650', 'DDR5', 4, 192, 'Micro-ATX', true, true, true, 'MSI'],
            ['Gigabyte B650 AORUS Elite', 'AM5', 'B650', 'DDR5', 4, 192, 'ATX', true, true, true, 'Gigabyte'],
        ];

        foreach ($list as [$name, $socket, $chipset, $ramType, $ramSlots, $maxRam, $formFactor, $wifi, $bt, $m2, $brandName]) {
            $brandId = DB::table('brands')->where('name', 'like', "%$brandName%")->value('id') ?? 1;

            $componentId = DB::table('components')->insertGetId([
                'name' => $name,
                'component_type_id' => $typeId,
                'brand_id' => $brandId,
                'category_id' => $categoryId,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('motherboards')->insert([
                'component_id' => $componentId,
                'socket' => $socket,
                'chipset' => $chipset,
                'ram_type' => $ramType,
                'ram_slots' => $ramSlots,
                'max_ram_capacity' => $maxRam,
                'form_factor' => $formFactor,
                'has_wifi' => $wifi,
                'has_bluetooth' => $bt,
                'has_m2_slot' => $m2,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }
}
