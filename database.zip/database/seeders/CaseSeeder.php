<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CaseSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $typeId = DB::table('component_types')->where('name', 'case')->value('id');
        $categoryId = DB::table('categories')->where('name', 'like', '%case%')->value('id');

        $cases = [
            ['NZXT H510', 'ATX', 381, false, 'NZXT'],
            ['Corsair 4000D Airflow', 'ATX', 360, false, 'Corsair'],
            ['Cooler Master MasterBox NR600', 'ATX', 410, false, 'Cooler Master'],
            ['Fractal Design Meshify C', 'ATX', 315, false, 'Fractal Design'],
            ['be quiet! Pure Base 500DX', 'ATX', 369, true, 'be quiet!'],
            ['Lian Li Lancool II Mesh', 'ATX', 384, true, 'Lian Li'],
            ['Phanteks Eclipse P400A', 'ATX', 420, true, 'Phanteks'],
            ['Thermaltake V200 TG', 'ATX', 380, true, 'Thermaltake'],
            ['MSI MAG Forge 100R', 'ATX', 330, true, 'MSI'],
            ['Cooler Master Q300L', 'Micro-ATX', 360, false, 'Cooler Master'],
        ];

        foreach ($cases as [$name, $formFactor, $maxGpuLength, $hasRgb, $brandName]) {
            $brandId = DB::table('brands')->where('name', 'like', "%$brandName%")->value('id') ?? 1;

            $componentId = DB::table('components')->insertGetId([
                'name' => $name,
                'component_type_id' => $typeId,
                'brand_id' => $brandId,
                'category_id' => $categoryId,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('case_models')->insert([
                'component_id' => $componentId,
                'form_factor' => $formFactor,
                'max_gpu_length' => $maxGpuLength,
                'has_rgb' => $hasRgb,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }
}
