<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CoolerSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $typeId = DB::table('component_types')->where('name', 'cooler')->value('id');
        $categoryId = DB::table('categories')->where('name', 'like', '%cooler%')->value('id');

        $coolers = [
            ['Cooler Master Hyper 212', 'AM4,LGA1200,LGA1700', 150, false, 'Cooler Master'],
            ['Noctua NH-D15', 'AM4,LGA1700', 220, false, 'Noctua'],
            ['be quiet! Pure Rock 2', 'AM4,LGA1200,LGA1151', 150, false, 'be quiet!'],
            ['Corsair iCUE H100i RGB', 'AM4,LGA1700', 250, true, 'Corsair'],
            ['NZXT Kraken X63', 'AM4,LGA1700', 280, true, 'NZXT'],
            ['Arctic Freezer 34 eSports', 'AM4,LGA1200', 180, false, 'Arctic'],
            ['Thermaltake UX200 ARGB', 'AM4,LGA1151', 130, true, 'Thermaltake'],
            ['MSI MAG CoreLiquid 240R', 'AM4,LGA1700', 250, true, 'MSI'],
            ['ID-Cooling SE-914-XT', 'AM4,LGA1200', 150, false, 'ID-Cooling'],
            ['Deepcool GAMMAXX 400', 'AM4,LGA1200', 180, false, 'Deepcool'],
        ];

        foreach ($coolers as [$name, $socketCompat, $tdp, $rgb, $brandName]) {
            $brandId = DB::table('brands')->where('name', 'like', "%$brandName%")->value('id') ?? 1;

            $componentId = DB::table('components')->insertGetId([
                'name' => $name,
                'component_type_id' => $typeId,
                'brand_id' => $brandId,
                'category_id' => $categoryId,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('coolers')->insert([
                'component_id' => $componentId,
                'socket_compatibility' => $socketCompat,
                'tdp' => $tdp,
                'has_rgb' => $rgb,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }
}
