<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
{
    Schema::table('components', function (Blueprint $table) {
        // Ajoute la colonne en nullable pour ne pas planter
        $table->foreignId('component_type_id')->nullable()->constrained('component_types');
    });
}

public function down(): void
{
    Schema::table('components', function (Blueprint $table) {
        $table->dropForeign(['component_type_id']);
        $table->dropColumn('component_type_id');
    });
}

};
